$(function(e) {
    // body...
    'use strict';


    $('.bxSlider').bxSlider({
        minSlides: 1,
        maxSlides: 4,
        slideWidth: 410,
        slideMargin: 10,
        // auto: true,
        hideControlOnEnd: false,
        infiniteLoop: true,
        responsive: true,
        touchEnabled: true
    });
});
